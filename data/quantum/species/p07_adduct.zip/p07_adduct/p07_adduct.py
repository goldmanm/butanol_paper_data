#!/usr/bin/env python
# -*- coding: utf-8 -*-

atoms = {
    'C': 4,
    'H': 9,
    'O': 3,
}

bonds = {
    'C-C': 3,
    'C=O': 1, 
    'C-H': 8,
    'O-H': 1,
	'O-O': 1
}

linear = False

#C1
externalSymmetry = 1

spinMultiplicity = 2

opticalIsomers = 2

energy = {
    'CBS-QB3': GaussianLog('p07_adduct.log'),
    'CCSD(T)-F12/cc-pVTZ-F12': MoleProLog('p07_adduct_f12.out'),
}

geometry = GaussianLog('p07_adduct.log')

frequencies = GaussianLog('p07_adductfreq.log')

rotors = [HinderedRotor(scanLog=GaussianLog('methyl_scan.log'), pivots=[2,8], top=[8,9,10,11], symmetry=3),
          HinderedRotor(scanLog=GaussianLog('methyl_scan.log'), pivots=[2,4], top=[4,5,6,7], symmetry=3),
		]
