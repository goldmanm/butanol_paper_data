#!/usr/bin/env python
# encoding: utf-8

modelChemistry = 'CCSD(T)-F12/cc-pVTZ-F12'
frequencyScaleFactor = 0.99
useHinderedRotors = True
useBondCorrections = True

species('p07_adduct', 'p07_adduct.py')

statmech('p07_adduct')
thermo('p07_adduct', 'NASA')
